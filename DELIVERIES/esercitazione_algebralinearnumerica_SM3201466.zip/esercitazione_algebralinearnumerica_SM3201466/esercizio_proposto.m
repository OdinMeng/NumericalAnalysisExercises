% SVOLGIMENTO DELL'ESERCIZIO PROPOSTO SULLA RISOLUZIONE DEI SISTEMI LINEARI
% DINO MENG [SM3201466], AIDA, 2024-2025
% SLIDE 17
A = [15, 6, 8, 11; 6,6,5,3;8,5,7,6; 11,3,6,9];

A1 = A; A2 = A^2; A3 = A^3;

x1 = A1 \ (A1*ones(4,1));
x2 = A2 \ (A2*ones(4,1));
x3 = A3 \ (A3*ones(4,1));

fprintf("SOLUZIONI AI SISTEMI LINEARI\n");
format long;
disp("X1");
disp(x1); 
disp("X2");
disp(x2); 
disp("X3");
disp(x3);

% Si nota che tutte le soluzioni si discostano dalla vera soluzione in una
% maniera più progressiva, nella prima si aveva una precisione di ordine
% 10^(-15), quindi quasi precisione macchina e nella seconda di ordine
% 10^(-12) e nella terza di ordine 10^(-6)

% Questo è dovuto al fatto che il fattore di condizionamento K(A) nel senso
% della norma 2 dipende dagli autovalori di A (in quanto è definita
% positiva, siccome ha autovalori positivi)
fprintf("AUTOVALORI DI A: ");
disp(eig(A))
K = max(eig(A)/min(eig(A)));
fprintf("FATTORE DI CONDIZIONAMENTO DI A1: %.8e\n", K);

% Per il fatto che se lambda è autovalore di A allora lambda^i è autovalore
% di A^i, si ha che tale fattore di condizionamento aumenta e aumentando
% quindi il rischio di propagare l'errore commesso.
fprintf("CONDIZIONAMENTO DI A2, A3: %.8e, %.8e\n", K^2, K^3);

input("Premere input per passare al prossimo esercizio.\n> ")
% SLIDE 25


eps_ = 1e-14;
A = [1, 1, -3; 2, 2-eps_, 4; 1,9,4];
x_true = [1; 1; 1];
b = A * x_true; 

% Risolvo Sistema Lineare con LUGAUSS
[L,U] = lugauss(A);
v = L \ b;
x_hat_lugauss = U \ v;

r = norm(b-A*x_hat_lugauss)/norm(b); % residuo relativo
err_rel = norm(x_hat_lugauss - x_true) / norm(x_true); % errore relativo

fprintf("RISULTATI SENZA PIVOTING:\n\t> RESIDUO RELATIVO: %.15f\n\t> ERRORE RELATIVO: %.15f\n", r, err_rel);

fprintf("--------------------------- X ---------------------------\n");
input("Premere enter per continuare: ")
fprintf("--------------------------- X ---------------------------\n");

% Risolvo Sistema Lineare SENZA Lugauss:;
[L,U, P] = lu(A);
v = L \ P*b;
x_hat = U \ v;

r_lu = norm(b-A*x_hat)/norm(b); % residuo relativo
err_rel_lu = norm(x_hat - x_true) / norm(x_true); % errore relativo

fprintf("RISULTATI CON PIVOTING:\n\t> RESIDUO RELATIVO: %.15f\n\t> ERRORE RELATIVO: %.15f\n", r_lu, err_rel_lu);

% sunto
fprintf("--------------------------- X ---------------------------\n");

fprintf("METODO\tRESIDUO RELATIVO\tERRORE RELATIVO\n")
fprintf("LUGAUSS\t%.16f\t%.16f\n", r, err_rel)

fprintf("LU_MATLAB\t%.16f\t%.16f\n", r_lu, err_rel_lu)